<div class="main layui-hide-sm layui-show-xs">
  <div class="layui-row">
    <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
        <div class="main-box">
        <div class="title">
              <p class="tit">{{ __('dujiaoka.site_announcement') }}:</p>
          </div>
          <div class="goods">
              <div class="tips">{!! dujiaoka_config_get('notice') !!}</div>
          </div>
      </div>
    </div>
  </div>
</div>