<div class="sh-notice">

    <div class="layui-row ">
        <!-- PC -->
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
            <div class="layui-card cardcon">
                <div class="layui-card-header">{{ __('dujiaoka.site_announcement') }}：</div>
                <div class="layui-card-body">
                    {!! dujiaoka_config_get('notice') !!}
                </div>
            </div>
        </div>
    </div>

</div>
