<script>
    let tipsMsg = {
        least_one    : '{{ __('layui.least_one') }}',
        exceeds      : '{{ __('layui.exceeds') }}',
        exceeds_limit: '{{ __('layui.exceeds_limit') }}',
        mobile_order : '{{ __('layui.mobile_order') }}'
    };
</script>
<script src="/assets/layui/layui/layui.js"></script>
<script src="/assets/layui/js/jquery-3.4.1.min.js"></script>
<script src="/assets/layui/main.js"></script>
<script src="/assets/layui/layui/lay/modules/layer.js"></script>
