<!DOCTYPE html>
<html lang="{{ str_replace('_','-',strtolower(app()->getLocale())) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($page_title) ? $page_title : '' }} | {{ dujiaoka_config_get('title') }}</title>
    @if(\Illuminate\Support\Facades\Request::path() == '/')
        <meta name="Keywords" content="{{ dujiaoka_config_get('keywords') }}">
        <meta name="Description" content="{{ dujiaoka_config_get('description') }}">
    @else
        <meta name="Keywords" content="{{ isset($gd_keywords) ? $gd_keywords : '' }}">
        <meta name="Description" content="{{ isset($gd_description) ? $gd_description : '' }}">
        <meta property="og:type" content="article">
        <meta property="og:image" content="{{ $picture }}">
        <meta property="og:title" content="{{ isset($page_title) ? $page_title : '' }}">
        <meta property="og:description" content="{{ isset($gd_description) ? $gd_description : '' }}">
        <meta property="og:release_date" content="{{ $updated_at }}">
    @endif
    <link rel="stylesheet" href="/assets/layui/css/layui.css">
    <link rel="stylesheet" href="/assets/style/main.css">
    <link rel="shortcut icon" href="/assets/style/favicon.ico" />
    @if(\request()->getScheme() == "https")
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    @endif

    <style>
        /* 在手机设备上，调整图标位置 */
        @media only screen and (max-width: 768px) {
            .sh-header .logo p {
                margin-right: 5px; /* 调整图标与文字之间的间距 */
            }
        }
    </style>
</head>
<body>
<div class="sh-header">
    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-sm12">
            <ul class="layui-nav layui-bg-blue" lay-filter="">
                <li class="layui-nav-item logo">
                    <p style="font-size: 16px; font-weight: 500" href="javascript:;" >
                        {{ dujiaoka_config_get('text_logo') }} |
                    </p>
                </li>
                <li class="layui-nav-item @if(\Illuminate\Support\Facades\Request::path() == '/') layui-this @endif">
                    <a href="/">{{__('dujiaoka.home_page')}}</a>
                </li>
                <li class="layui-nav-item @if(\Illuminate\Support\Facades\Request::url() == url('order-search')) layui-this @endif">
                    <a href="{{ url('order-search') }}">
                        <i class="layui-icon layui-icon-search"></i>{{ __('dujiaoka.order_search') }}
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
</body>
</html>
